#!/usr/bin/env python3
"""
Convierte el export de Stitch (carpetas con code.html) en un sitio estático
interconectado dentro de ./site, listo para Netlify.

Uso:
    python3 build.py ruta/a/stitch_web_page_replica

Se puede volver a ejecutar cada vez que re-exportes desde Stitch.
"""
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).parent
SITE = ROOT / "site"
WA = "https://wa.me/51979723880"  # número que ya usan las pantallas del propio export

# carpeta de Stitch (prefijo)  ->  (archivo final, título)
PAGES = {
    "novaris_per_tienda_oficial": ("index.html", "NOVARIS Perú | Tienda Oficial de Relojes y Accesorios"),
    "novaris_per_colecci_n_hombres": ("hombres.html", "NOVARIS Perú | Colección Hombres"),
    "novaris_per_colecci_n_mujeres": ("mujeres.html", "NOVARIS Perú | Colección Mujeres"),
    "novaris_per_colecci_n_parejas": ("parejas.html", None),  # ya trae <title>
    "novaris_per_colecci_n_ofertas": ("ofertas.html", "NOVARIS Perú | Ofertas Exclusivas"),
    "novaris_per_detalle_de_producto": ("detalle-producto.html", "NOVARIS Perú | Detalle de Producto"),
    "novaris_per_pantalla_de_pago": ("checkout.html", "NOVARIS Perú | Checkout Seguro"),
    "novaris_per_mi_perfil_de_usuario_cuenta_vip_firma": ("perfil.html", "NOVARIS Perú | Mi Perfil VIP"),
    "novaris_per_mi_perfil_de_usuario_cuenta_vip": ("perfil-basico.html", "NOVARIS Perú | Mi Perfil"),
    "novaris_per_mis_pedidos_seguimiento_en_tiempo_real_1": ("tracking.html", "NOVARIS Perú | Mis Pedidos"),
    "novaris_per_mis_pedidos_seguimiento_en_tiempo_real_2": ("tracking-shalom.html", "NOVARIS Perú | Seguimiento Shalom"),
    "novaris_admin_configuraci_n_inicial": ("admin.html", None),  # login (ya trae <title>)
    "novaris_admin_editor_visual": ("admin-cms.html", None),
    "novaris_admin_configuraci_n_de_perfil": ("admin-seguridad.html", "NOVARIS Admin | Perfil y Seguridad"),
}

# Enlaces muertos (href="#" o vacío): se resuelven por el texto visible del <a>.
# Orden importa: gana la primera regla que coincide.
LINK_RULES = [
    (r"^(novaris\s*per[uú]|per[uú]|tienda master)$", "index.html"),
    (r"^inicio$", "index.html"),
    (r"^hombres$", "hombres.html"),
    (r"^mujeres$", "mujeres.html"),
    (r"^parejas?$", "parejas.html"),
    (r"^colecci[oó]n parejas$", "parejas.html"),
    (r"^ofertas( exclusivas)?$", "ofertas.html"),
    (r"^(mis pedidos|ver historial de \d+ pedidos|rastrear( mi)? pedido)$", "tracking.html"),
    (r"^(mi perfil|ingresar|novaris club.*|[aá]rea de clientes|mi cuenta.*)$", "perfil.html"),
    (r"^(0|finalizar compra ahora|finalizar pedido.*)$", "checkout.html"),
    (r"^billeteras y lentes$", "hombres.html#billeteras"),
    (r"^(whatsapp soporte|pedir por whatsapp|cont[aá]ctanos)$", WA),
    # panel admin
    (r"^editor visual & cms$", "admin-cms.html"),
    (r"^(seguridad & accesos|configuraci[oó]n sitio)$", "admin-seguridad.html"),
    (r"^cat[aá]logo hombres$", "hombres.html"),
    (r"^gu[ií]a shalom per[uú]$", "tracking-shalom.html"),
    (r"^ver tienda novaris$", "index.html"),
]

ICON_TRAIL = r"(north_east|open_in_new|arrow_forward|chevron_right|download)$"
ANCHOR = re.compile(r"<a\b([^>]*?)>(.*?)</a>", re.S)


def clean(inner: str) -> str:
    t = re.sub(r"<[^>]+>", " ", inner)
    t = t.replace("&amp;", "&")
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"^[a-z_]+\s*(?=[A-ZÁÉÍÓÚÑ¿0-9])", "", t)  # icono Material al inicio (pegado o con espacio)
    t = re.sub(r"\s*" + ICON_TRAIL, "", t).strip()
    return t


def resolve(text: str):
    low = text.lower()
    for pat, dest in LINK_RULES:
        if re.search(pat, low):
            return dest
    return None


def rewire(html: str) -> str:
    def sub(m):
        attrs, inner = m.group(1), m.group(2)
        hm = re.search(r'href="([^"]*)"', attrs)
        if not hm or hm.group(1) not in ("#", "", "#checkout"):  # "#checkout" apuntaba a un ancla inexistente
            return m.group(0)
        dest = resolve(clean(inner))
        if not dest:
            return m.group(0)
        attrs = attrs.replace(hm.group(0), f'href="{dest}"')
        if dest.startswith("http") and "target=" not in attrs:
            attrs += ' target="_blank" rel="noopener"'
        return f"<a{attrs}>{inner}</a>"

    return ANCHOR.sub(sub, html)


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    src = Path(sys.argv[1])
    if SITE.exists():
        shutil.rmtree(SITE)
    (SITE / "assets").mkdir(parents=True)

    # logo (la carpeta "image_from_https_novarisperu...")
    for d in src.iterdir():
        if d.name.startswith("image_from_https_novarisperu"):
            shutil.copy(d / "screen.png", SITE / "assets" / "logo-novaris.png")

    favicon = '<link rel="icon" type="image/png" href="/assets/logo-novaris.png">'
    done = set()
    # prefijos más largos primero para que "..._firma" no se confunda con "..._cuenta_vip"
    for d in sorted(src.iterdir()):
        code = d / "code.html"
        if not code.exists():
            continue
        key = max((k for k in PAGES if d.name.startswith(k)), key=len, default=None)
        if key is None:
            print(f"  ! sin ruta definida para {d.name}")
            continue
        out, title = PAGES[key]
        h = code.read_text(encoding="utf-8")
        h = rewire(h)
        if out == "admin.html":
            # tras el login iba a "admin.html" (= esta misma pantalla): bucle. Va al CMS.
            h = h.replace("window.location.href='admin.html'", "window.location.href='admin-cms.html'")
        if title and "<title" not in h:
            h = re.sub(r"(<head[^>]*>)", rf"\1<title>{title}</title>", h, count=1)
        if "rel=\"icon\"" not in h:
            h = re.sub(r"(<head[^>]*>)", rf"\1{favicon}", h, count=1)
        (SITE / out).write_text(h, encoding="utf-8")
        done.add(out)
        print(f"  {d.name[:55]:55s} -> {out}")

    print(f"\n{len(done)} páginas generadas en {SITE}")


if __name__ == "__main__":
    main()
