---
name: Crimson Horology Luxury
colors:
  surface: '#f9f9fa'
  surface-dim: '#dadadb'
  surface-bright: '#f9f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeef'
  surface-container-high: '#e8e8e9'
  surface-container-highest: '#e2e2e3'
  on-surface: '#1a1c1d'
  on-surface-variant: '#5b403d'
  inverse-surface: '#2f3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#8f6f6c'
  outline-variant: '#e4beba'
  surface-tint: '#ba1a20'
  primary: '#af101a'
  on-primary: '#ffffff'
  primary-container: '#d32f2f'
  on-primary-container: '#fff2f0'
  inverse-primary: '#ffb3ac'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2e1'
  on-secondary-container: '#656464'
  tertiary: '#6a5432'
  on-tertiary: '#ffffff'
  tertiary-container: '#846c48'
  on-tertiary-container: '#fff3e6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#930010'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#fedeb2'
  tertiary-fixed-dim: '#e0c298'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#584323'
  background: '#f9f9fa'
  on-background: '#1a1c1d'
  surface-variant: '#e2e2e3'
  crimson-deep: '#8B0000'
  crimson-vibrant: '#EB4747'
  crimson-dark: '#5A050D'
  obsidian-pure: '#0D0D0D'
  charcoal-surface: '#1A1A1A'
  champagne-gold: '#D4AF37'
  neutral-silver: '#E5E7EB'
  surface-light: '#FAFAFA'
typography:
  headline-xl:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 26px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: 0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '800'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-xxl: 4rem
---

## Brand & Style

The design system establishes a high-conversion, accessible luxury atmosphere crafted specifically for premium timepieces and lifestyle jewelry. The brand persona blends timeless sophistication with commercial dynamism: combining the allure of haute horlogerie with clear, high-trust retail execution tailored for the Peruvian e-commerce market (highlighting localized payment on delivery, rapid dispatch, and authentic craftsmanship).

The visual aesthetic balances **Modern High-Contrast Minimalism** and **Refined Editorial Luxury**:
- **Contrast & Depth:** A stark interplay of pure white surfaces, deep obsidian black grounds, and intense crimson red focal points that direct user gaze seamlessly toward promotions, purchase triggers, and urgency badges.
- **Editorial Poise:** High-contrast editorial display typography evokes fine Swiss or Milanese design catalogues, while crisp sans-serif body typography provides optimal legibility for product specifications, pricing, and checkout funnels.
- **Dynamic Tactility:** Subtle champagne gold borders and soft neutral surfaces elevate cards from generic digital store grids into curated jewelry display cases.

## Colors

The palette balances intense commercial energy with luxury restraint:
- **Primary (`#D32F2F` / `#EB4747`):** The signature vibrant crimson red, extracted directly from brand heritage banners and logomarks. Reserved for high-value actions, cart triggers, 'Oferta' badges, and conversion touchpoints.
- **Secondary (`#111111` / `#0D0D0D`):** Jet obsidian black used for high-fashion contrast, header bars, footer grounding, and primary typographic hierarchy.
- **Tertiary (`#C5A880` / `#D4AF37`):** Muted champagne gold that delivers warmth and authentic jewelry association, used for subtle borders, star ratings, and luxury guarantee seals.
- **Neutral (`#F8F8F9` / `#E5E7EB`):** Crisp silver-toned off-white that keeps product photography pristine without cold clinical glare.
- **Crimson Dark (`#5A050D`):** Deep wine shadow red utilized for hero gradients, banner overlays, and press interactions.

## Typography

The pairing marries high-fashion editorial presence with digital commerce velocity:
- **Display & Section Titles (`Bodoni Moda`):** Delivers striking, high-contrast neoclassical serifs that mirror the brand's logo glyphs and luxury horology pedigree. Used selectively for collection names, promotional campaign banners, and lifestyle statements.
- **Product Details & UI (`Plus Jakarta Sans`):** Provides pristine optical legibility at scale. Its geometric balance ensures prices (e.g., `S/. 129.90`), product names, and countdown timers remain legible even on smaller mobile viewports.
- **Caps Hierarchy:** Labels, category names, and badge markers utilize uppercase styling with deliberate tracking (`letter-spacing: 0.04em` to `0.08em`) to reinforce precision and prestige.

## Layout & Spacing

The layout system leverages a fluid, responsive 12-column grid for desktop views (max container width: 1320px) transitioning into a 4-column layout for mobile:
- **Product Grids:** Desktop renders 4 or 5 items per row with `gutter: 1.25rem`, allowing watch dials to remain expansive. Mobile defaults to a strict 2-column grid (`gutter-mobile: 0.75rem`) to maintain product density without micro-cluttering.
- **Vertical Cadence:** Section breaks between major categories (Hombres, Mujeres, Parejas) employ generous breathing room (`space-xxl` on desktop, `space-xl` on mobile) to let rich photography breathe.
- **Micro Spacing:** Product card metadata (title, original price, discounted price, savings tag) follows a compressed `space-xs` and `space-sm` vertical stack, ensuring immediate visual linkage.

## Elevation & Depth

Visual depth is achieved through tactile, low-diffusion ambient layers rather than murky dropshadows, ensuring clean timepiece presentation:
- **Base Level (Canvas):** Flat pure white `#FFFFFF` or pale pearl `#F8F8F9`.
- **Card Surfaces:** Defined by ultra-thin hairline borders (`1px solid #E5E7EB`) with hover states introducing an ambient lift: `0 10px 25px -5px rgba(0, 0, 0, 0.08)`.
- **Floating Conversion Elements:** Sticky bottom purchase bars and active cart modals utilize soft layered diffusion: `0 20px 40px -10px rgba(17, 17, 17, 0.15)`.
- **Trust Overlays & Modals:** High-conversion popups ("Compra Tranquilo / Paga al Recibir") use a strong backdrop dimming layer (`rgba(17, 17, 17, 0.75)`) combined with crisp white cards edged with subtle gold or crimson accents.

## Shapes

The design system incorporates **Pill-shaped (Level 3)** contours for interactive components, contrasting gracefully against the strict architectural rectangularity of product imagery:
- **Buttons & Call-to-Actions:** Generously rounded pill shapes (`border-radius: 9999px`) provide inviting, tactile click targets that stand out against rectangular product cards.
- **Offer & Savings Badges:** Pill-shaped capsules with slight padding to hug dynamic discount text.
- **Product Tiles & Banner Containers:** Structured with minimal rounding (`0.375rem` / 6px) to avoid cropping watch strap lugs and jewelry display angles.
- **Input Fields:** Soft rounded rectangles (`0.5rem` / 8px) balancing formal luxury with effortless typing convenience.

## Components

### Buttons
- **Primary Promotional (Action):** Pill-shaped, saturated crimson background (`#D32F2F`), text in pure white (`#FFFFFF`) in `Plus Jakarta Sans` 700 uppercase with double-chevron indicator (`VER MÁS >>`). Hover transitions to dark crimson (`#8B0000`) with smooth transform `scale(1.02)`.
- **Secondary (Dark Luxury):** Jet black (`#111111`) fill with white text, ideal for "Añadir al Carrito" and checkout initiation.
- **Tertiary / Outline:** Pure white background, `1px solid #111111` border, black text. Hover shifts to full black fill with white text.

### Badges & Chips
- **Badge 'Oferta' & 'Ahorro':** Vibrant crimson pill badge placed floating at the top-left or bottom of product imagery. Typography: `label-sm` bold uppercase with explicit savings callout (e.g., `AHORRAS S/. 20.00`).
- **Urgency / Stock Indicator:** Slim inline chip with gold tertiary or crimson accent dot indicating fast Peruvian dispatch (`Envío Hoy en Lima`).

### Product Cards
- **Structure:** Vertical stack starting with an aspect-ratio 1:1 image container with neutral pearl backdrop (`#FAFAFA`), subtle zoom transition on photo hover.
- **Content:** Product model title in uppercase `title-md`, secondary brand mark (e.g., Poedagar, Chenxi), dual-price structure featuring crossed-out original price in neutral grey (`#9CA3AF`) and bold discounted price in crimson (`#D32F2F`) alongside quick-add cart button.

### Form Inputs & Search
- **Search Bar:** Minimalist rounded container with subtle border (`1px solid #E5E7EB`), internal magnifying glass icon, and faint placeholder text `Busca tu reloj o accesorio...`. Focus ring in subtle gold/red glow without harsh browser outlines.

### Promotional Banners & Trust Anchors
- **Hero Category Splitters:** Dynamic tri-split cards (Hombres / Mujeres / Parejas) featuring rich crimson vignette backgrounds, photographic cutouts, and floating pill CTA buttons.
- **Payment & Guarantee Ribbon:** High-trust container highlighting "Haz tu pedido -> Paga en tu casa" (Pago Contraentrega) featuring Shalom and courier visual badges, structured with clear dual-column trust markers.